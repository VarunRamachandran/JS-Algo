# Hangman-js-console-game
The classic hangman game in the javascript console
Open the console to play and type help(); for instructions
