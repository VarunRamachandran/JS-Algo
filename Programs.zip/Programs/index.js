
// 1. Count Characters 

// 2. Count Characters Refractored

// 3. Same Naive Solution 
//    The function should return true if every value in the array has it's corresponding value squared in the second array.
   

// 4.  Same Refractored Solution 
//     The function should return true if every value in the array has it's corresponding value squared in the second array.
//     Refractored Solution.

// 5.  Anagram My Solution

// 6.  Anagram Refractored Solution.

// 7.  Anagram Refractored again Solution

// 8.  Sum Zero Naive The function should find the first pair where the sum is 0.

// 9.  Sum Zero ( Multiple Pointers) Refractored The function should find the first pair where the sum is 0.

// 10. Count Unique Values Implement a function called countUniqueValues

// 11. SLIDING WINDOW Navie Solution
//     Write a function called maxSubarraySum which accepts an array of integers and a number called n.

// 12. SLIDING WINDOW REFRACTORED
//     Write a function called maxSubarraySum which accepts an array of integers and a number called n.


// 13. Divide and Conquer NAIVE SOLUTION
//     Given a sorted array of integers, write a function called search, that accepts a value and returns the index where the value passed to the function is located. 

// 14. Divide and Conquer REFRACTORED SOLUTION

// 15. 
